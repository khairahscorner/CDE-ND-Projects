import { NotifyProductAddToOrderConsole } from './notify-product-add-to-order-console';

export const EventHandlers = [NotifyProductAddToOrderConsole];
